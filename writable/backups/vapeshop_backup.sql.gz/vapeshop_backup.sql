-- Database Backup
-- Generated: 2026-04-16 00:29:04
-- Database: vapeshop_db

-- Table: audit_logs
CREATE TABLE `audit_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `resource_type` varchar(50) DEFAULT NULL,
  `resource_id` int(11) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  `status` enum('success','failed','warning') NOT NULL DEFAULT 'success',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action` (`action`),
  KEY `resource_type` (`resource_type`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: inventory_movements
CREATE TABLE `inventory_movements` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) unsigned NOT NULL,
  `movement_type` enum('initial','adjustment','purchase','sale','return','inventory') NOT NULL DEFAULT 'adjustment',
  `quantity` int(11) NOT NULL,
  `unit_cost` decimal(10,2) DEFAULT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` int(11) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_movements_created_by_foreign` (`created_by`),
  KEY `product_id` (`product_id`),
  KEY `movement_type` (`movement_type`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `inventory_movements_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `inventory_movements_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: inventory_movements
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('1', '1', 'initial', '25', NULL, 'product', '1', 'Initial stock', NULL, '2026-04-15 15:46:09');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('2', '2', 'initial', '50', NULL, 'product', '2', 'Initial stock', NULL, '2026-04-15 15:46:09');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('3', '3', 'initial', '8', NULL, 'product', '3', 'Initial stock', NULL, '2026-04-15 15:46:09');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('4', '4', 'initial', '15', NULL, 'product', '4', 'Initial stock', NULL, '2026-04-15 15:46:09');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('5', '5', 'initial', '30', NULL, 'product', '5', 'Initial stock', NULL, '2026-04-15 15:46:09');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('6', '6', 'initial', '5', NULL, 'product', '6', 'Initial stock', NULL, '2026-04-15 15:46:09');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('7', '7', 'initial', '12', NULL, 'product', '7', 'Initial stock', NULL, '2026-04-15 15:46:09');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('8', '8', 'initial', '12', NULL, 'product', '8', 'Initial stock', NULL, '2026-04-15 15:46:09');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('9', '9', 'initial', '20', NULL, 'product', '9', 'Initial stock', NULL, '2026-04-15 15:46:09');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('10', '10', 'initial', '18', NULL, 'product', '10', 'Initial stock', NULL, '2026-04-15 15:46:09');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('11', '1', 'sale', '-1', NULL, 'product', '1', NULL, NULL, '2026-04-15 16:01:32');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('12', '2', 'sale', '-1', NULL, 'product', '2', NULL, NULL, '2026-04-15 16:01:32');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('13', '3', 'sale', '-1', NULL, 'product', '3', NULL, NULL, '2026-04-15 16:01:32');

-- Table: login_attempts
CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `attempt_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ip_address_success_attempt_time` (`ip_address`,`success`,`attempt_time`),
  KEY `email_attempt_time` (`email`,`attempt_time`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: login_attempts
INSERT INTO `login_attempts` (`id`, `email`, `ip_address`, `user_agent`, `success`, `attempt_time`) VALUES ('1', 'admin@vapeshop.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '1', '2026-04-15 15:46:22');
INSERT INTO `login_attempts` (`id`, `email`, `ip_address`, `user_agent`, `success`, `attempt_time`) VALUES ('2', 'customer@vapeshop.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '1', '2026-04-15 16:01:18');
INSERT INTO `login_attempts` (`id`, `email`, `ip_address`, `user_agent`, `success`, `attempt_time`) VALUES ('3', 'admin@vapeshop.com', '::1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/147.0.0.0 Safari/537.36', '1', '2026-04-16 00:28:46');

-- Table: migrations
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: migrations
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('1', '2026-02-18-141226', 'App\\Database\\Migrations\\CreateUsersTable', 'default', 'App', '1776267961', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('2', '2026-02-24-110225', 'App\\Database\\Migrations\\CreatePasswordResetsTable', 'default', 'App', '1776267961', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('3', '2026-02-26-150000', 'App\\Database\\Migrations\\CreateRecordsTable', 'default', 'App', '1776267961', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('4', '2026-03-06-010000', 'App\\Database\\Migrations\\CreateLoginAttemptsTable', 'default', 'App', '1776267961', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('5', '2026-03-12-230000', 'App\\Database\\Migrations\\CreateProductsTable', 'default', 'App', '1776267961', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('6', '2026-03-13-000000', 'App\\Database\\Migrations\\CreateOrderTables', 'default', 'App', '1776267961', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('7', '2026-04-08-152200', 'App\\Database\\Migrations\\CreateOtpCodesTable', 'default', 'App', '1776267961', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('8', '2026-04-09-210000', 'App\\Database\\Migrations\\CreateRefreshTokensTable', 'default', 'App', '1776267961', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('9', '2026-04-09-260000', 'App\\Database\\Migrations\\CreateAuditLogsTable', 'default', 'App', '1776267961', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('10', '2026-04-15-010000', 'App\\Database\\Migrations\\ExpandSensitiveUserFieldsForEncryption', 'default', 'App', '1776267961', '1');

-- Table: order_items
CREATE TABLE `order_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) unsigned NOT NULL,
  `product_id` int(11) unsigned DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) unsigned NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: order_items
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `quantity`, `unit_price`, `created_at`, `updated_at`) VALUES ('1', '1', '3', 'Replacement Coil Pack', '1', '450.00', '2026-04-15 16:01:29', '2026-04-15 16:01:29');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `quantity`, `unit_price`, `created_at`, `updated_at`) VALUES ('2', '1', '2', 'Salt Mint E-Liquid', '1', '320.00', '2026-04-15 16:01:29', '2026-04-15 16:01:29');
INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `product_name`, `quantity`, `unit_price`, `created_at`, `updated_at`) VALUES ('3', '1', '1', 'VapeHub X Pod Kit', '1', '1250.00', '2026-04-15 16:01:29', '2026-04-15 16:01:29');

-- Table: order_payments
CREATE TABLE `order_payments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) unsigned NOT NULL,
  `method` enum('cash','card','gcash','bank_transfer') NOT NULL DEFAULT 'cash',
  `status` enum('paid','partial','unpaid','pending') NOT NULL DEFAULT 'unpaid',
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `amount_received` decimal(12,2) DEFAULT NULL,
  `change_amount` decimal(12,2) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `status` (`status`),
  CONSTRAINT `order_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: order_payments
INSERT INTO `order_payments` (`id`, `order_id`, `method`, `status`, `amount`, `amount_received`, `change_amount`, `paid_at`, `created_at`, `updated_at`) VALUES ('1', '1', 'cash', 'paid', '2020.00', '2020.00', '0.00', '2026-04-15 16:01:32', '2026-04-15 16:01:29', '2026-04-15 16:01:32');

-- Table: order_shipments
CREATE TABLE `order_shipments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) unsigned NOT NULL,
  `status` enum('to_pay','to_ship','to_receive','completed','cancelled','return_refund','failed_delivery') NOT NULL DEFAULT 'to_pay',
  `tracking_number` varchar(100) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `shipped_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `status` (`status`),
  CONSTRAINT `order_shipments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: order_shipments
INSERT INTO `order_shipments` (`id`, `order_id`, `status`, `tracking_number`, `shipping_address`, `contact_number`, `shipped_at`, `delivered_at`, `notes`, `created_at`, `updated_at`) VALUES ('1', '1', 'completed', NULL, '22 Vapor Street, Bagong Pag-asa, Quezon City, Metro Manila, 1100, Philippines', '+63 900 000 0002', NULL, '2026-04-15 16:02:00', NULL, '2026-04-15 16:01:29', '2026-04-15 16:02:00');

-- Table: orders
CREATE TABLE `orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned DEFAULT NULL,
  `reference_number` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `order_date` date NOT NULL,
  `status` enum('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference_number` (`reference_number`),
  KEY `customer_id` (`customer_id`),
  KEY `order_date` (`order_date`),
  KEY `status` (`status`),
  CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: orders
INSERT INTO `orders` (`id`, `customer_id`, `reference_number`, `title`, `description`, `order_date`, `status`, `notes`, `created_at`, `updated_at`) VALUES ('1', '2', 'RCPT-20260415-2505', 'Direct Order', 'Customer direct order purchase.', '2026-04-15', 'completed', NULL, '2026-04-15 16:01:29', '2026-04-15 16:02:00');

-- Table: otp_codes
CREATE TABLE `otp_codes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `otp_code` varchar(6) NOT NULL,
  `expiry_time` datetime NOT NULL,
  `attempts` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `expiry_time` (`expiry_time`),
  CONSTRAINT `otp_codes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: password_resets
CREATE TABLE `password_resets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `is_used` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `email_token` (`email`,`token`),
  KEY `expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: product_categories
CREATE TABLE `product_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: product_categories
INSERT INTO `product_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES ('1', 'Pods', 'pods', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `product_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES ('2', 'E-Liquid', 'e-liquid', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `product_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES ('3', 'Accessories', 'accessories', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `product_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES ('4', 'Devices', 'devices', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `product_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES ('5', 'Disposable', 'disposable', '2026-04-15 15:46:09', '2026-04-15 15:46:09');

-- Table: products
CREATE TABLE `products` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `status` (`status`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: products
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('1', '1', 'VapeHub X Pod Kit', 'Compact pod system with smooth draw and advanced coil technology. Perfect for beginners and experienced vapers alike.', '1250.00', NULL, 'active', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('2', '2', 'Salt Mint E-Liquid', 'Refreshing mint flavor with smooth nicotine salt formulation. 30ml bottle with 50mg nicotine strength.', '320.00', NULL, 'active', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('3', '3', 'Replacement Coil Pack', 'Long-life mesh coils (pack of 3). Compatible with most pod systems. Provides excellent flavor and vapor production.', '450.00', NULL, 'active', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('4', '3', 'Portable Charger Case', 'Fast charging pocket case with 2000mAh battery. USB-C compatible with LED indicators. Keep your device powered all day.', '680.00', NULL, 'active', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('5', '2', 'Mango Tango E-Liquid', 'Tropical mango and tangerine blend with sweet and tangy notes. 30ml bottle with 35mg nicotine salt.', '350.00', NULL, 'active', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('6', '4', 'Pro Vapor Mod', 'Advanced box mod with temperature control and variable wattage. 200W maximum output with large color display.', '2800.00', NULL, 'active', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('7', '5', 'Menthol Chill Disposable', 'Ice-cold menthol disposable vape with smooth draw and long-lasting flavor.', '450.00', NULL, 'active', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('8', '3', 'Ceramic Tank', '2ml capacity ceramic tank with top-fill design. Leak-proof construction with adjustable airflow.', '550.00', NULL, 'active', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('9', '3', '18650 Battery Pack', 'High-drain 3000mAh batteries (pack of 2). 35A continuous discharge with protection circuit.', '750.00', NULL, 'active', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('10', '2', 'Berry Blast E-Liquid', 'Mixed berry explosion with strawberry, blueberry, and raspberry. Sweet and tangy with smooth finish.', '330.00', NULL, 'active', '2026-04-15 15:46:09', '2026-04-15 15:46:09');

-- Table: records
CREATE TABLE `records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `record_type` enum('purchase','inventory','expense') NOT NULL DEFAULT 'expense',
  `record_date` date NOT NULL,
  `reference_number` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `quantity` int(11) unsigned NOT NULL DEFAULT 0,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('cash','card','gcash','bank_transfer') DEFAULT NULL,
  `payment_status` enum('paid','partial','unpaid') NOT NULL DEFAULT 'unpaid',
  `status` enum('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `record_type` (`record_type`),
  KEY `record_date` (`record_date`),
  KEY `status` (`status`),
  KEY `reference_number` (`reference_number`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `records_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: records
INSERT INTO `records` (`id`, `record_type`, `record_date`, `reference_number`, `title`, `description`, `quantity`, `unit_price`, `payment_method`, `payment_status`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES ('1', 'purchase', '2026-04-13', 'PUR-2026-0001', 'Restock Coils', 'Supplier restock for coils.', '50', '3.20', 'bank_transfer', 'paid', 'completed', 'Invoice settled in full.', '1', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `records` (`id`, `record_type`, `record_date`, `reference_number`, `title`, `description`, `quantity`, `unit_price`, `payment_method`, `payment_status`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES ('2', 'inventory', '2026-04-12', 'INV-2026-0001', 'Pod Cartridge Stock Count', 'Monthly stock update.', '120', '4.00', 'cash', 'paid', 'completed', 'Physical count matched expected stock.', '1', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `records` (`id`, `record_type`, `record_date`, `reference_number`, `title`, `description`, `quantity`, `unit_price`, `payment_method`, `payment_status`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES ('3', 'expense', '2026-04-11', 'EXP-2026-0001', 'Store Utilities', 'Electricity and internet billing.', '1', '145.75', 'card', 'unpaid', 'pending', 'Due next billing cycle.', '1', '2026-04-15 15:46:09', '2026-04-15 15:46:09');

-- Table: refresh_tokens
CREATE TABLE `refresh_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `token_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `is_revoked` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `token_hash` (`token_hash`),
  KEY `expires_at` (`expires_at`),
  KEY `is_revoked` (`is_revoked`),
  CONSTRAINT `refresh_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: user_addresses
CREATE TABLE `user_addresses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `address_line` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `barangay` text DEFAULT NULL,
  `province` text DEFAULT NULL,
  `postal_code` text DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `user_id_is_primary` (`user_id`,`is_primary`),
  CONSTRAINT `user_addresses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: user_addresses
INSERT INTO `user_addresses` (`id`, `user_id`, `address_line`, `city`, `country`, `barangay`, `province`, `postal_code`, `is_primary`, `created_at`, `updated_at`) VALUES ('1', '1', 'kNDKw+FLiDPifj5NWx0GePZfEiROU3EBd9T0LgGohJsgqEw20Vm3xRxLfMjLYptuhUILc/SkWXNUs/NWrZYllvc1Gcy7Ls262zaPviueUP5kFU3T56/llTx2t5U9r2fiyCjYIaI=', 'JmGkE2uxd4bNOnfc8EW3vD2eCsRA4EqTOk7PXYXw05oYnC4ECRHaUSScVGeCkPDW8oprhlVYncfGj6/gyTk9PEamH7RwRYrLvWZp6UL2sIAaN/+p3jw=', 'LrFqitDNDXaGNLDxTLfP6UfQDgwgSnJ8Bh+kBVm6eqD7V3q/7Yj7xfV7u/1rj94f5lFTwr7LIIO8tjQ20IjqI0ZdHx90O0u5OznB7pdeaH9DvRZTnbHiuvV6WQ==', 'cB6JI8QoAMxagi5Dux2zhmk+nBSEAYm+AGCslgT0t/8IXuayu2BWFCPH9WnVUdmCEJdfADv32bblEc3AUJn7EqqUJlCG6v+vKLg4v8NKqFJo+Gf3sEc0g/oD', 'kos6UZUZbyMi57934upzCh1qJIFHIIP2K3MfwAfXpRtxMjMnb+whag6EIwsIW1Z3gi3jERYNbzpc5pQgNQC4J/MXHJQ06jYcxVLacJ6KDjiCVSLcsfGnWf/F3AM=', '4yUxtc2iBUTrpvHy1DzSX2HckLvFUv0qqJo7gvs3F5nkR2mTDgmESNvXxgsnNLjAqwazTKRgyTpEx5IjxKwrfsoBtKb30drJw3OtOdj/rqaqf2vs', '1', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `user_addresses` (`id`, `user_id`, `address_line`, `city`, `country`, `barangay`, `province`, `postal_code`, `is_primary`, `created_at`, `updated_at`) VALUES ('2', '2', '/UAQfElWHO5eSE8qpxS5E+2lyI/ubF1qMa6vh8h2/t3mw1jsbbpIgmIoz/gdl+Bg59Ho67rH7ig5K9j0v6DetlLDo7suDx2qDqNjc7FuNc7xTSXhrSzFBN76hc3N/9Y=', 'm3y9EKGGGHBbkdMU4AWDhzg4xV6MlbrkcVBURzpDiYsmhiHxWWxjHnguqByWr+yuzp2tD4vBiS5Te1vFqN1zqhyWg2nmILqsgKTEIi1Lj49fv5n415k/tjDXpw==', 'ZDf3oPIrqYYSmGWLuBfwEsX0r+XyPvQtAdiNWbKDJRuGH/Qna5zNvqJSJnEJla+5tkevFxDPlpqceAGkAHXMPQV57LD/NfYAnlRBtBTy1dhlB/DP9QzKmUCMIw==', 'J8WIlq5BgsHfESkfoSe2yQHJC34pJjT3yQ3Pr9817yM1E/WSV0pYw8KborgYQhHvqojXTvgRlCR63g+b3xi3Ifc9u07v/fNlrDGnRF8V+CvG05aW2CiUpskMoEzC0Q==', 'RtPSu0oyCkiUMp2EoxM4mws21ev42ouc5lkGbxbQSth5LeAIS66iYS5YeuFjzNNjdDm9vshLL3/mHPLZ/8bI/h5l6BMQcCv9ENtEzaug6nvWee3FfZYthKEYdEc=', 'pS9UmB4FcL+anGFu7qzsX/pWMXxypHpVKBZeDXjUFhDPpnPC1UkrdEuGDd6//uRONT27Oc3ykT6UiVYLwyM+k6DSO05bdigdYUzUfKQmYXcF50co', '1', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `user_addresses` (`id`, `user_id`, `address_line`, `city`, `country`, `barangay`, `province`, `postal_code`, `is_primary`, `created_at`, `updated_at`) VALUES ('3', '5', 'OVMZ/gIJ+khxR+x0uYAt/m3tRKMe4VTGjWP9+aQZEZvtrjTfQBrOga7TTY36T92COT24gGdANDSSVmeimT+Ro1Pv029Or886KVmdEB8l7ewaf5MVo+vmNWxgmhJQElLkx4STGx8+ZESj1frwpElIZDE=', 'zafTNLH9EIjKbBQOgbaKC817wRmTDfzRYPkoAuKLB0WNLZhfmfAXDQ10HfYGGE/O9RY1J7Hmz3hjtNkBFD4NfX7DbKnHbOaTZs8ekV4GMJsM2LoNYS4=', NULL, NULL, 'W6YB0nCMAdM3sjvENqOCrvBNYb1IEi6S+M82+19kx1cykGQ/ZpL94j4I9Ew29r7/+L14BZviz0lfQnubhOmRRZ6KYlJQbYapO2uXTJMNYqVXRfkF2e09D7k=', 'HL+wgKn9nsbqjo+iQ4PJwaWqrAmKxLJAopNh9E/889AlBcnWmts442TCegykVnT/XTqNtCd3PmjWP1mICAWg/OMXFJleVTXraY8TEWWDLs4zCn/C', '1', '2026-04-16 00:27:56', '2026-04-16 00:27:56');

-- Table: user_profiles
CREATE TABLE `user_profiles` (
  `user_id` int(11) unsigned NOT NULL,
  `phone_number` text DEFAULT NULL,
  `legal_age_confirmed` tinyint(1) NOT NULL DEFAULT 0,
  `last_login` datetime DEFAULT NULL,
  `login_attempts` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: user_profiles
INSERT INTO `user_profiles` (`user_id`, `phone_number`, `legal_age_confirmed`, `last_login`, `login_attempts`, `locked_until`, `created_at`, `updated_at`) VALUES ('1', '+63 900 000 0001', '1', '2026-04-16 00:28:46', '0', NULL, '2026-04-15 15:46:09', '2026-04-16 00:28:46');
INSERT INTO `user_profiles` (`user_id`, `phone_number`, `legal_age_confirmed`, `last_login`, `login_attempts`, `locked_until`, `created_at`, `updated_at`) VALUES ('2', '+63 900 000 0002', '1', '2026-04-15 16:01:18', '0', NULL, '2026-04-15 15:46:09', '2026-04-15 16:01:18');
INSERT INTO `user_profiles` (`user_id`, `phone_number`, `legal_age_confirmed`, `last_login`, `login_attempts`, `locked_until`, `created_at`, `updated_at`) VALUES ('4', NULL, '0', NULL, '0', NULL, '2026-04-16 00:24:33', '2026-04-16 00:24:33');
INSERT INTO `user_profiles` (`user_id`, `phone_number`, `legal_age_confirmed`, `last_login`, `login_attempts`, `locked_until`, `created_at`, `updated_at`) VALUES ('5', 'shyKamZqwVbq7clBpwO1qfxg02hov2SnFBOXHOmQVM734nmvAG0mvpHPXfD7EJNa0kDGv6uDhLQ+QuuM2cJx4prLA26vqy1iMbLgEndxmG7k4apr6Z6pCZ0KAQ==', '1', NULL, '0', NULL, '2026-04-16 00:27:56', '2026-04-16 00:27:56');

-- Table: users
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL DEFAULT 'customer',
  `shop_name` varchar(150) DEFAULT NULL,
  `approval_status` varchar(20) NOT NULL DEFAULT 'approved',
  `verification_id_path` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `role` (`role`),
  KEY `approval_status` (`approval_status`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: users
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `shop_name`, `approval_status`, `verification_id_path`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'Administrator', 'admin@vapeshop.com', '$argon2id$v=19$m=65536,t=4,p=2$Wk1KUEl1algzbnVxLmdlMA$4pUGxSoceNQskzQG08RiSnk1QWP8LLHx2ekgYwSI6dE', 'admin', 'Quick Puff Vape Shop', 'approved', NULL, '1', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `shop_name`, `approval_status`, `verification_id_path`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'Customer', 'customer@vapeshop.com', '$argon2id$v=19$m=65536,t=4,p=2$eXQ2TEFJc1YzeTZnSy93Tw$mXCFhqPT6MxweB6lkB9otHswKOmhgYNQIX/GDnW3OF0', 'customer', NULL, 'approved', NULL, '1', '2026-04-15 15:46:09', '2026-04-15 15:46:09');
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `shop_name`, `approval_status`, `verification_id_path`, `is_active`, `created_at`, `updated_at`) VALUES ('4', 'Neil Vincent Dionio', 'neilvincentdionio@gmail.com', '$argon2id$v=19$m=65536,t=4,p=2$NElwTURKclQudklRY1IvRQ$BuwflgLgQ7KHnika6QLgS7JSXBPqNP3A2OUVHcbPCzc', 'customer', NULL, 'approved', NULL, '1', '2026-04-16 00:24:33', '2026-04-16 00:24:33');
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `shop_name`, `approval_status`, `verification_id_path`, `is_active`, `created_at`, `updated_at`) VALUES ('5', 'vincedionio', 'vincedionio@vapeshop.com', '$argon2id$v=19$m=65536,t=4,p=2$QS9MejlNRi5IYzd3ZGN0Mg$Q1blZdBcXDZVObqcp69NFre+ZuYLhRvBzSuR8sb4tvw', 'customer', NULL, 'pending', 'customer_ids/1776270476_c48614824ad49f4d0a83.jpg', '0', '2026-04-16 00:27:56', '2026-04-16 00:27:56');

