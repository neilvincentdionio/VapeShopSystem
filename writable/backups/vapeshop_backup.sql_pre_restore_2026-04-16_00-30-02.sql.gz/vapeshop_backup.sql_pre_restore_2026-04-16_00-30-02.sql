-- Database Backup
-- Generated: 2026-04-16 00:30:02
-- Database: vapeshop_db

-- Table: audit_logs
CREATE TABLE `audit_logs` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned DEFAULT NULL,
  `action` varchar(100) NOT NULL,
  `resource_type` varchar(50) DEFAULT NULL,
  `resource_id` int(11) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `details` text DEFAULT NULL,
  `status` enum('success','failed','warning') NOT NULL DEFAULT 'success',
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `action` (`action`),
  KEY `resource_type` (`resource_type`),
  KEY `status` (`status`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: inventory_movements
CREATE TABLE `inventory_movements` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(11) unsigned NOT NULL,
  `movement_type` enum('initial','adjustment','purchase','sale','return','inventory') NOT NULL DEFAULT 'adjustment',
  `quantity` int(11) NOT NULL,
  `unit_cost` decimal(10,2) DEFAULT NULL,
  `reference_type` varchar(50) DEFAULT NULL,
  `reference_id` int(11) unsigned DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `inventory_movements_created_by_foreign` (`created_by`),
  KEY `product_id` (`product_id`),
  KEY `movement_type` (`movement_type`),
  KEY `created_at` (`created_at`),
  CONSTRAINT `inventory_movements_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL,
  CONSTRAINT `inventory_movements_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: inventory_movements
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('1', '1', 'initial', '25', NULL, 'product', '1', 'Initial stock', NULL, '2026-04-16 00:29:48');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('2', '2', 'initial', '50', NULL, 'product', '2', 'Initial stock', NULL, '2026-04-16 00:29:48');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('3', '3', 'initial', '8', NULL, 'product', '3', 'Initial stock', NULL, '2026-04-16 00:29:48');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('4', '4', 'initial', '15', NULL, 'product', '4', 'Initial stock', NULL, '2026-04-16 00:29:48');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('5', '5', 'initial', '30', NULL, 'product', '5', 'Initial stock', NULL, '2026-04-16 00:29:48');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('6', '6', 'initial', '5', NULL, 'product', '6', 'Initial stock', NULL, '2026-04-16 00:29:48');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('7', '7', 'initial', '12', NULL, 'product', '7', 'Initial stock', NULL, '2026-04-16 00:29:48');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('8', '8', 'initial', '12', NULL, 'product', '8', 'Initial stock', NULL, '2026-04-16 00:29:48');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('9', '9', 'initial', '20', NULL, 'product', '9', 'Initial stock', NULL, '2026-04-16 00:29:48');
INSERT INTO `inventory_movements` (`id`, `product_id`, `movement_type`, `quantity`, `unit_cost`, `reference_type`, `reference_id`, `notes`, `created_by`, `created_at`) VALUES ('10', '10', 'initial', '18', NULL, 'product', '10', 'Initial stock', NULL, '2026-04-16 00:29:48');

-- Table: login_attempts
CREATE TABLE `login_attempts` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `user_agent` text DEFAULT NULL,
  `success` tinyint(1) NOT NULL DEFAULT 0,
  `attempt_time` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ip_address_success_attempt_time` (`ip_address`,`success`,`attempt_time`),
  KEY `email_attempt_time` (`email`,`attempt_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: migrations
CREATE TABLE `migrations` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `version` varchar(255) NOT NULL,
  `class` varchar(255) NOT NULL,
  `group` varchar(255) NOT NULL,
  `namespace` varchar(255) NOT NULL,
  `time` int(11) NOT NULL,
  `batch` int(11) unsigned NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: migrations
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('1', '2026-02-18-141226', 'App\\Database\\Migrations\\CreateUsersTable', 'default', 'App', '1776270571', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('2', '2026-02-24-110225', 'App\\Database\\Migrations\\CreatePasswordResetsTable', 'default', 'App', '1776270571', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('3', '2026-02-26-150000', 'App\\Database\\Migrations\\CreateRecordsTable', 'default', 'App', '1776270571', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('4', '2026-03-06-010000', 'App\\Database\\Migrations\\CreateLoginAttemptsTable', 'default', 'App', '1776270571', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('5', '2026-03-12-230000', 'App\\Database\\Migrations\\CreateProductsTable', 'default', 'App', '1776270571', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('6', '2026-03-13-000000', 'App\\Database\\Migrations\\CreateOrderTables', 'default', 'App', '1776270571', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('7', '2026-04-08-152200', 'App\\Database\\Migrations\\CreateOtpCodesTable', 'default', 'App', '1776270571', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('8', '2026-04-09-210000', 'App\\Database\\Migrations\\CreateRefreshTokensTable', 'default', 'App', '1776270571', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('9', '2026-04-09-260000', 'App\\Database\\Migrations\\CreateAuditLogsTable', 'default', 'App', '1776270571', '1');
INSERT INTO `migrations` (`id`, `version`, `class`, `group`, `namespace`, `time`, `batch`) VALUES ('10', '2026-04-15-010000', 'App\\Database\\Migrations\\ExpandSensitiveUserFieldsForEncryption', 'default', 'App', '1776270571', '1');

-- Table: order_items
CREATE TABLE `order_items` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) unsigned NOT NULL,
  `product_id` int(11) unsigned DEFAULT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) unsigned NOT NULL DEFAULT 1,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `product_id` (`product_id`),
  CONSTRAINT `order_items_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `order_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: order_payments
CREATE TABLE `order_payments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) unsigned NOT NULL,
  `method` enum('cash','card','gcash','bank_transfer') NOT NULL DEFAULT 'cash',
  `status` enum('paid','partial','unpaid','pending') NOT NULL DEFAULT 'unpaid',
  `amount` decimal(12,2) NOT NULL DEFAULT 0.00,
  `amount_received` decimal(12,2) DEFAULT NULL,
  `change_amount` decimal(12,2) DEFAULT NULL,
  `paid_at` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `status` (`status`),
  CONSTRAINT `order_payments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: order_shipments
CREATE TABLE `order_shipments` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `order_id` int(11) unsigned NOT NULL,
  `status` enum('to_pay','to_ship','to_receive','completed','cancelled','return_refund','failed_delivery') NOT NULL DEFAULT 'to_pay',
  `tracking_number` varchar(100) DEFAULT NULL,
  `shipping_address` text DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `shipped_at` datetime DEFAULT NULL,
  `delivered_at` datetime DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `order_id` (`order_id`),
  KEY `status` (`status`),
  CONSTRAINT `order_shipments_order_id_foreign` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: orders
CREATE TABLE `orders` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) unsigned DEFAULT NULL,
  `reference_number` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `order_date` date NOT NULL,
  `status` enum('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `reference_number` (`reference_number`),
  KEY `customer_id` (`customer_id`),
  KEY `order_date` (`order_date`),
  KEY `status` (`status`),
  CONSTRAINT `orders_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: otp_codes
CREATE TABLE `otp_codes` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `otp_code` varchar(6) NOT NULL,
  `expiry_time` datetime NOT NULL,
  `attempts` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `expiry_time` (`expiry_time`),
  CONSTRAINT `otp_codes_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: password_resets
CREATE TABLE `password_resets` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `created_at` datetime NOT NULL,
  `is_used` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `email_token` (`email`,`token`),
  KEY `expires_at` (`expires_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: product_categories
CREATE TABLE `product_categories` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `slug` varchar(120) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: product_categories
INSERT INTO `product_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES ('1', 'Pods', 'pods', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `product_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES ('2', 'E-Liquid', 'e-liquid', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `product_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES ('3', 'Accessories', 'accessories', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `product_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES ('4', 'Devices', 'devices', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `product_categories` (`id`, `name`, `slug`, `created_at`, `updated_at`) VALUES ('5', 'Disposable', 'disposable', '2026-04-16 00:29:48', '2026-04-16 00:29:48');

-- Table: products
CREATE TABLE `products` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `category_id` int(11) unsigned NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `image` varchar(255) DEFAULT NULL,
  `status` enum('active','inactive') NOT NULL DEFAULT 'active',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `category_id` (`category_id`),
  KEY `status` (`status`),
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `product_categories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: products
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('1', '1', 'VapeHub X Pod Kit', 'Compact pod system with smooth draw and advanced coil technology. Perfect for beginners and experienced vapers alike.', '1250.00', NULL, 'active', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('2', '2', 'Salt Mint E-Liquid', 'Refreshing mint flavor with smooth nicotine salt formulation. 30ml bottle with 50mg nicotine strength.', '320.00', NULL, 'active', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('3', '3', 'Replacement Coil Pack', 'Long-life mesh coils (pack of 3). Compatible with most pod systems. Provides excellent flavor and vapor production.', '450.00', NULL, 'active', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('4', '3', 'Portable Charger Case', 'Fast charging pocket case with 2000mAh battery. USB-C compatible with LED indicators. Keep your device powered all day.', '680.00', NULL, 'active', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('5', '2', 'Mango Tango E-Liquid', 'Tropical mango and tangerine blend with sweet and tangy notes. 30ml bottle with 35mg nicotine salt.', '350.00', NULL, 'active', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('6', '4', 'Pro Vapor Mod', 'Advanced box mod with temperature control and variable wattage. 200W maximum output with large color display.', '2800.00', NULL, 'active', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('7', '5', 'Menthol Chill Disposable', 'Ice-cold menthol disposable vape with smooth draw and long-lasting flavor.', '450.00', NULL, 'active', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('8', '3', 'Ceramic Tank', '2ml capacity ceramic tank with top-fill design. Leak-proof construction with adjustable airflow.', '550.00', NULL, 'active', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('9', '3', '18650 Battery Pack', 'High-drain 3000mAh batteries (pack of 2). 35A continuous discharge with protection circuit.', '750.00', NULL, 'active', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `products` (`id`, `category_id`, `name`, `description`, `price`, `image`, `status`, `created_at`, `updated_at`) VALUES ('10', '2', 'Berry Blast E-Liquid', 'Mixed berry explosion with strawberry, blueberry, and raspberry. Sweet and tangy with smooth finish.', '330.00', NULL, 'active', '2026-04-16 00:29:48', '2026-04-16 00:29:48');

-- Table: records
CREATE TABLE `records` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `record_type` enum('purchase','inventory','expense') NOT NULL DEFAULT 'expense',
  `record_date` date NOT NULL,
  `reference_number` varchar(100) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `quantity` int(11) unsigned NOT NULL DEFAULT 0,
  `unit_price` decimal(10,2) NOT NULL DEFAULT 0.00,
  `payment_method` enum('cash','card','gcash','bank_transfer') DEFAULT NULL,
  `payment_status` enum('paid','partial','unpaid') NOT NULL DEFAULT 'unpaid',
  `status` enum('pending','completed','cancelled') NOT NULL DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `created_by` int(11) unsigned DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `record_type` (`record_type`),
  KEY `record_date` (`record_date`),
  KEY `status` (`status`),
  KEY `reference_number` (`reference_number`),
  KEY `created_by` (`created_by`),
  CONSTRAINT `records_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: records
INSERT INTO `records` (`id`, `record_type`, `record_date`, `reference_number`, `title`, `description`, `quantity`, `unit_price`, `payment_method`, `payment_status`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES ('1', 'purchase', '2026-04-14', 'PUR-2026-0001', 'Restock Coils', 'Supplier restock for coils.', '50', '3.20', 'bank_transfer', 'paid', 'completed', 'Invoice settled in full.', '1', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `records` (`id`, `record_type`, `record_date`, `reference_number`, `title`, `description`, `quantity`, `unit_price`, `payment_method`, `payment_status`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES ('2', 'inventory', '2026-04-13', 'INV-2026-0001', 'Pod Cartridge Stock Count', 'Monthly stock update.', '120', '4.00', 'cash', 'paid', 'completed', 'Physical count matched expected stock.', '1', '2026-04-16 00:29:48', '2026-04-16 00:29:48');
INSERT INTO `records` (`id`, `record_type`, `record_date`, `reference_number`, `title`, `description`, `quantity`, `unit_price`, `payment_method`, `payment_status`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES ('3', 'expense', '2026-04-12', 'EXP-2026-0001', 'Store Utilities', 'Electricity and internet billing.', '1', '145.75', 'card', 'unpaid', 'pending', 'Due next billing cycle.', '1', '2026-04-16 00:29:48', '2026-04-16 00:29:48');

-- Table: refresh_tokens
CREATE TABLE `refresh_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `token_hash` varchar(255) NOT NULL,
  `expires_at` datetime NOT NULL,
  `is_revoked` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `token_hash` (`token_hash`),
  KEY `expires_at` (`expires_at`),
  KEY `is_revoked` (`is_revoked`),
  CONSTRAINT `refresh_tokens_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Table: user_addresses
CREATE TABLE `user_addresses` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `address_line` text DEFAULT NULL,
  `city` text DEFAULT NULL,
  `country` text DEFAULT NULL,
  `barangay` text DEFAULT NULL,
  `province` text DEFAULT NULL,
  `postal_code` text DEFAULT NULL,
  `is_primary` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `user_id_is_primary` (`user_id`,`is_primary`),
  CONSTRAINT `user_addresses_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: user_addresses
INSERT INTO `user_addresses` (`id`, `user_id`, `address_line`, `city`, `country`, `barangay`, `province`, `postal_code`, `is_primary`, `created_at`, `updated_at`) VALUES ('1', '1', 'NulDuYujbcoMIW0ENZ7/FDVsZf3DLAb0FkOm2xrumM7dIn6rId0lCph7wyC1YzHoLaki+F1zLSaal9KbVYRYlAgr2Pcc5ePKy5ZSe7xsBqJkkVzMImoScS74NVrsGDuAB4OS8E4=', 'DZoJDEi4w4hZ/WfcqrVWAc+Ee+WMZV29W+p9hq4d0e/pGHsaHjlzR2jk3AdTr1ZSvmlR/7FTDdA/ofY0xW+pRySc28ud/zWW8sG81XIZKT31F3CwJBM=', '8fDYVQcubzJLAsaTlHipM/i+6PATEbjKcOW/D310TJaWjvCMSbQym3OXJHmFlq/ClDdnr5dEeIPbS+acvfdR6OTYYB/VZR8OS/p4hlb4djgBC7w4rO0cePjRbw==', 'XGaAO06St/0iPTkzkTdPTtxzNrnnm8HgprVldnSwEPpx6IebrmBLlzqepE+uOluoGnfw69oihz0WKYrbRF7wW8TYRCNlkXlbAxcpfsnmY8ynsg60vNZYIRK3', 'SUJ3KslTTjyKsxyoyCyHSe339N0BOqJJwlRtCg/o41cAR7Jt6+iozl6VYqXQOTfMT89C4FJRrsMiEn0Ma8AwDob5EOVDl5Kzq9Kxpxhzqna8VuHkZhflxXOu6M0=', 'd5dtH44b2RPaNDUn7GgcYPy3YJ9rdeHi5seZ4+eJSBHtwH5DCgwe50s6V+hiOkVeOKl6ZCEMpbrW/4INvSrsTJRuUk6sZd7SGbwLnQVj6N5vwzV+', '1', '2026-04-16 00:29:38', '2026-04-16 00:29:38');
INSERT INTO `user_addresses` (`id`, `user_id`, `address_line`, `city`, `country`, `barangay`, `province`, `postal_code`, `is_primary`, `created_at`, `updated_at`) VALUES ('2', '2', 'Z16t+ctYZE2eWDvyJajKPM/tIoeRrxsWIFanydyUbVjZshD72b0fjmQz41mwBr+8YN1khyHHuycrQPcy8WFPDbjKRQ7COZPWanRjjjjRpgaTX/xXM2XLcvQkMQ75H9Q=', '2URgubVd3363ypnKuKeRprlBGptpAh6NhlUC3CjNPdL21g9ltSt6LF4hAkj8cIMJLOc+Sgafxe1QgwU6W1HCk88UDfVPN/p4/bnp4Q8bWWxfJmI7PS5NaI+7pQ==', 'IUMqUzAWUMEx0mQyuiolTAXVO7+eEWMSGCftpgo0l09+4Aj+KnEF8dwArz3sPr4x0ihaIrPMyStieHCdSt7uR+ZyDZadjAVIil8/nAGQKgDBMoQHWq2xBwmomA==', 'VIJGhhLC+NObZVTUaaS2RGak12W+9QVk2/01xbhD8j8oG4x3WIOaRlKw4ZEYHCoYco7cemYY3r0sJmmuXtvgS7qiWkhxW5WqW7u6x5GtlJdttABkEtvTOaDsVablWw==', 'hyF0+2gDquXX/sVahLbz+bCe3QIdDvS5CpmhgALw9jw4TB2xdnI9HEpKrr8dJ00UoDwOqdfZhNeF86QviUYLNq5xxCmv6x0JWCI1B2vp9iqEyQni1gEKTJ2id1M=', 'LtQrwftBdUf0cf99pLlPGa4ubUhDduAzCIzfIx9ce0eApexbg1GFwDSV3cQFygIKeUpQaYTbOzJuBQPwQEDr6XWJACSU56ME5U8v/XJJrIsjWnoh', '1', '2026-04-16 00:29:38', '2026-04-16 00:29:38');

-- Table: user_profiles
CREATE TABLE `user_profiles` (
  `user_id` int(11) unsigned NOT NULL,
  `phone_number` text DEFAULT NULL,
  `legal_age_confirmed` tinyint(1) NOT NULL DEFAULT 0,
  `last_login` datetime DEFAULT NULL,
  `login_attempts` int(11) NOT NULL DEFAULT 0,
  `locked_until` datetime DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `user_profiles_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: user_profiles
INSERT INTO `user_profiles` (`user_id`, `phone_number`, `legal_age_confirmed`, `last_login`, `login_attempts`, `locked_until`, `created_at`, `updated_at`) VALUES ('1', '/QyYykZU7yc79/HgsMfUKiMXiMXV/Sn7soRFlx+vhGy/ZpT5OykrIhpuPO/ZbqIOVMqKJtjhkDonyREaBI/Rj80ybB4L1Ast3pTIZ+iUpI/Q3eTgT1Wakwmr3GuLP5op', '1', NULL, '0', NULL, '2026-04-16 00:29:38', '2026-04-16 00:29:38');
INSERT INTO `user_profiles` (`user_id`, `phone_number`, `legal_age_confirmed`, `last_login`, `login_attempts`, `locked_until`, `created_at`, `updated_at`) VALUES ('2', 'EWtOW7XtFmwMOR30T9pHcQur/okRUjhyIPhssvzwan5HgTqTtIJ2gS8Y9hqoM+Pb81J1mSFXVzIBYi/N3UkgXyTB0QdQzw5ckuDW8ygEV47847AA6yGyPhh1ErUWwvmH', '1', NULL, '0', NULL, '2026-04-16 00:29:38', '2026-04-16 00:29:38');

-- Table: users
CREATE TABLE `users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` enum('admin','customer') NOT NULL DEFAULT 'customer',
  `shop_name` varchar(150) DEFAULT NULL,
  `approval_status` varchar(20) NOT NULL DEFAULT 'approved',
  `verification_id_path` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`),
  KEY `role` (`role`),
  KEY `approval_status` (`approval_status`),
  KEY `is_active` (`is_active`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- Data for table: users
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `shop_name`, `approval_status`, `verification_id_path`, `is_active`, `created_at`, `updated_at`) VALUES ('1', 'Administrator', 'admin@vapeshop.com', '$argon2id$v=19$m=65536,t=4,p=2$VW5oT01jL3pJejdLRlZvTQ$8yzTlLHbIPPqOTfetTt2ok0AEfbhz9eobi7h+OTvjsk', 'admin', 'Quick Puff Vape Shop', 'approved', NULL, '1', '2026-04-16 00:29:38', '2026-04-16 00:29:38');
INSERT INTO `users` (`id`, `name`, `email`, `password`, `role`, `shop_name`, `approval_status`, `verification_id_path`, `is_active`, `created_at`, `updated_at`) VALUES ('2', 'Customer', 'customer@vapeshop.com', '$argon2id$v=19$m=65536,t=4,p=2$Qkh6VmdUT1laR1g0WDZFeQ$6ixZJ7iC4V31mMiKczlPsjV0mgJ3xMq99uJtiTCp/GM', 'customer', NULL, 'approved', NULL, '1', '2026-04-16 00:29:38', '2026-04-16 00:29:38');

